import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show kIsWeb;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    throw UnsupportedError('Only web is supported on Zapp.run.');
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey:            'AIzaSyDXXXBnriV8wYM5x8cISdcZIocyL-GffUU',
    appId:             '1:498587035742:web:07b51450318e997e49accf',
    messagingSenderId: '498587035742',
    projectId:         'todoappsample-e14ef',
    authDomain:        'todoappsample-e14ef.firebaseapp.com',
    storageBucket:     'todoappsample-e14ef.appspot.com',
  );
}