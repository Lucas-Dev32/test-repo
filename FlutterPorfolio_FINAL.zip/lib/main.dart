import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
void main() {
  //starting point of every dart file
  runApp(const SimplePortfolioApp());
  //Flutter function that launch our application
  //Function - standalone block of code
  //Method - function that define w/in a class operates on objects data
  //MyApp() - your application 
}

class SimplePortfolioApp extends StatelessWidget {
  //Class name
  //const - doesn't change after building application
  const SimplePortfolioApp({Key? key}) :super(key: key);
  @override
  Widget build (BuildContext context) {
    return MaterialApp(
    debugShowCheckedModeBanner: false, //removees debug banner
    title: 'Portfolio',
    theme: ThemeData(
       primarySwatch: Colors.yellow, 
       scaffoldBackgroundColor: Color(0xFFF5F5F5),
    ),
    home: HomePage(),
  );
  }
}

class HomePage extends StatefulWidget{
  const HomePage({Key? key}) : super(key: key);
@override
State<HomePage> createState() => _HomePageState();
/*State - return the objects
  State for the HomePage
  createState - Method
  _HomePageState() - hold data that can chage, trigger rebuild
  the application*/
}
  class _HomePageState extends State<HomePage>{
    String selectedPage = 'Home';
    late ScrollController _scrollController;

  @override
    void initState(){
      super.initState();
      _scrollController = ScrollController();
    }

  Widget _buildContent(){
    if (selectedPage == 'Home'){
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ClipOval(
            child: Image.asset(
              'lib/assets/images/profile1.jpeg',
              width: 120,
              height: 120,
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(height: 16,),
          Text(
            'Lucas, Jonel P.',
            style: GoogleFonts.poppins(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'BSCS 2201',
            style: GoogleFonts.roboto(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 8,),
          Text(
            'Mobile Programming Activity',
            style: GoogleFonts.roboto(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
        ],
      );
    }
    else if (selectedPage == 'About'){
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ClipOval(
            child: Image.asset(
              'lib/assets/images/profile2.jpeg',
              width: 120,
              height: 120,
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(height: 16,),
          Text(
            'About Me',
              style: GoogleFonts.poppins(
                fontSize: 32,
                fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Hello I am Lucas, a CS student of STI and an aspiring Programmer.',
            style: GoogleFonts.poppins(
              fontSize: 16,
            ),
          ),
        ],
      );
    }
    else if (selectedPage == "Skills"){
      return Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipOval(
            child: Image.asset(
              'lib/assets/images/bulb.jpg',
              width: 120,
              height: 120,
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(height: 16,),
          Text(
            'Skills',
              style: GoogleFonts.poppins(
                fontSize: 32,
                fontWeight: FontWeight.bold,
              ),
          ),
          SizedBox(height: 10,),
          Text('Adept at Java and C# Programming Language',
            style: GoogleFonts.poppins(
              fontSize: 16,
              color: Colors.grey[700],
            ),
          ),
          Text('Proficient at Microsoft Word and PowerPoint',
            style: GoogleFonts.poppins(
              fontSize: 16,
              color: Colors.grey[700],
            ),
          ),
        ],
      );
    }
    else if (selectedPage == 'Contact'){
      return Column(
         mainAxisAlignment: MainAxisAlignment.start,
         crossAxisAlignment: CrossAxisAlignment.start,
         children: [
          ClipOval(
            child: Image.asset(
              'lib/assets/images/phone.jpg',
              width: 120,
              height: 120,
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(height: 16,),
          Text(
            'My Contacts',
              style: GoogleFonts.poppins(
                fontSize: 32,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8,),
            Text.rich(
              TextSpan(
                children: [
                  TextSpan(
                    text: 'Email: ',
                    style: GoogleFonts.roboto(
                      fontSize: 16, 
                      color: Colors.grey[600]),
                  ),
                  TextSpan(
                    text: 'lucasjonel1337@gmail.com',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      color: Colors.grey[700]),
                  ),
                ],
              ),
            ),
            SizedBox(height: 8,),
            Text.rich(
              TextSpan(
                children: [
                  TextSpan(
                    text: 'Mobile Number: ',
                    style: GoogleFonts.roboto(
                      fontSize: 16, 
                      color: Colors.grey[600]),
                  ),
                  TextSpan(
                    text: '+639364754789',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      color: Colors.grey[700]),
                  ),
                ],
              ),
            ),
         ],
      );
    }
    return Text('Coming soon: $selectedPage');
  }

  @override
  Widget build (BuildContext context){
    return Scaffold( /*page structure (holds appbar, drawer body*/
      backgroundColor: Color(0xFFF5F5F5),
      appBar: AppBar(
        leading: Builder(
          builder: (BuildContext context){
            return IconButton(
              icon: Icon(Icons.menu),
              onPressed: (){
                Scaffold.of(context).openDrawer();
            },
          );
        }
      ),
      title: Text('Portfolio',
      style: GoogleFonts.poppins(fontSize: 20, fontWeight: FontWeight.w600),
      ),
    ),
    drawer: Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration (
              color: Colors.yellow,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ClipOval(
                  child: Image.asset(
                    'lib/assets/images/MAGIK.jpg',
                    width: 80,
                    height: 80,
                    fit: BoxFit.cover,
                  ),
                ),
                Text('Jonel P. Lucas',
                  style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.bold,),
                  ),
                  SizedBox(height: 4),
                Text('BSCS Student',
                style: GoogleFonts.roboto(fontSize: 14,),
                ),
              ],
            ),
          ),
          ListTile(
            leading: Icon(Icons.home, color: Colors.yellow,),
            title: Text('Home'),
            onTap: (){
              Navigator.pop(context);
              setState((){
                selectedPage = 'Home';
              });
            }
          ),
          ListTile(
            leading: Icon(Icons.person, color: Colors.yellow,),
            title: Text('About'),
            onTap: (){
              Navigator.pop(context);
              setState((){
                selectedPage = 'About';
              });
            }
          ),
          ListTile(
            leading: Icon(Icons.lightbulb, color: Colors.yellow,),
            title: Text('Skills'),
            onTap: (){
              Navigator.pop(context);
              setState((){
                selectedPage = 'Skills';
              });
            }
          ),
          ListTile(
            leading: Icon(Icons.email, color: Colors.yellow,),
            title: Text('Contact'),
            onTap: (){
              Navigator.pop(context);
              setState((){
                selectedPage = 'Contact';
              });
            }
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.download, color: Colors.yellow),
            title: Text('Download Resume'),
            onTap: (){
              Navigator.pop(context);
              print('Download Resume tapped');
            },
          ),
        ],
      )
    ),
    body: SingleChildScrollView(
      controller: _scrollController,
      child: Padding(
        padding: EdgeInsets.all(20),
        child: selectedPage == 'Home' || selectedPage == 'About'
              ? Center(child: _buildContent())
              : _buildContent(),
      ),
    ),
  );
}
  
  @override
    void dispose(){
      _scrollController.dispose();
      super.dispose();
    }
}
 