import 'package:flutter/material.dart';

void main() => runApp(const SocialApp());

class Post {
  final String username;
  final String avatar;
  final String content;
  final String timeAgo;
  int likes;
  bool liked;
  final List<Comment> comments;

  Post({
    required this.username,
    required this.avatar,
    required this.content,
    required this.timeAgo,
    this.likes = 0,
    this.liked = false,
    List<Comment>? comments,
  }) : comments = comments ?? [];
}

class Comment {
  final String username;
  final String text;
  Comment({required this.username, required this.text});
}

class SocialApp extends StatelessWidget {
  const SocialApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Novae',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6C63FF),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  final List<Post> _posts = [ //post placeholder
    Post(
      username: 'sparrowEx3',
      avatar: 'S',
      content: 'Just got married with my femboy lover <3.',
      timeAgo: '2m ago',
      likes: 24,
      comments: [
        Comment(username: 'maria', text: 'Congrats! Brother'),
        Comment(username: 'josh_k', text: 'Femboy is the best 🔥'),
      ],
    ),
    Post(
      username: 'maria_photos',
      avatar: 'M',
      content: 'Golden hour at the beach today 🌅 Nothing beats this view.',
      timeAgo: '15m ago',
      likes: 87,
      comments: [
        Comment(username: 'alex_dev', text: 'Stunning! Where is this?'),
      ],
    ),
    Post(
      username: 'susoBryan',
      avatar: 'SB',
      content: 'May pasok po kami ngayon kuya, Bat naniningil ka ng buo!!',
      timeAgo: '1h ago',
      likes: 142,
      comments: [
        Comment(username: 'sparrowEx3', text: 'Teacher ka tanga 😅'),
        Comment(username: 'maria_photos', text: 'Bakit kasi pumasok ka pa lol!'),
      ],
    ),
    Post(
      username: 'MagikW',
      avatar: 'W',
      content: 'Just finished cleaning "Limbo". Might do it again idk lol :p ',
      timeAgo: '3h ago',
      likes: 56,
    ),
  ];

  void _addPost(String content) { //place holder kapag nag post ka ilalabas ung name and time ng post
    setState(() {
      _posts.insert(
        0,
        Post(
          username: 'LucasDev',
          avatar: 'L',
          content: content,
          timeAgo: 'just now',
          likes: 0,
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      FeedPage(posts: _posts),
      SearchPage(),
      CreatePostPage(onPost: _addPost),
      ProfilePage(),
    ];

    return Scaffold(
      body: pages[_currentIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (i) => setState(() => _currentIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Feed'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
          NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'Post'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

// ── FEED ─────────────────────────────────────────────────────────────────────

class FeedPage extends StatefulWidget { // feed page
  final List<Post> posts;
  const FeedPage({super.key, required this.posts});

  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Novae', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24)),
        actions: [
          IconButton(icon: const Icon(Icons.notifications_outlined), onPressed: () {}),
        ],
      ),
      body: ListView.separated(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: widget.posts.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, i) => PostCard(
          post: widget.posts[i],
          onLike: () => setState(() {
            final p = widget.posts[i];
            p.liked = !p.liked;
            p.likes += p.liked ? 1 : -1;
          }),
        ),
      ),
    );
  }
}

class PostCard extends StatelessWidget { //post page
  final Post post;
  final VoidCallback onLike;
  const PostCard({super.key, required this.post, required this.onLike});

  @override
  Widget build(BuildContext context) {
    final color = _avatarColor(post.username);
    return InkWell(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => PostDetailPage(post: post)),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: color,
                  child: Text(post.avatar, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(post.username, style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text(post.timeAgo, style: TextStyle(color: Colors.grey[500], fontSize: 12)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(post.content, style: const TextStyle(fontSize: 15)),
            const SizedBox(height: 10),
            Row(
              children: [
                GestureDetector(
                  onTap: onLike,
                  child: Row(
                    children: [
                      Icon(
                        post.liked ? Icons.favorite : Icons.favorite_border,
                        size: 20,
                        color: post.liked ? Colors.red : Colors.grey,
                      ),
                      const SizedBox(width: 4),
                      Text('${post.likes}', style: TextStyle(color: Colors.grey[600])),
                    ],
                  ),
                ),
                const SizedBox(width: 20),
                Icon(Icons.chat_bubble_outline, size: 20, color: Colors.grey[600]),
                const SizedBox(width: 4),
                Text('${post.comments.length}', style: TextStyle(color: Colors.grey[600])),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

Color _avatarColor(String name) {
  final colors = [Colors.purple, Colors.indigo, Colors.teal, Colors.orange, Colors.pink, Colors.green];
  return colors[name.codeUnitAt(0) % colors.length];
}

// ── POST DETAIL ───────────────────────────────────────────────────────────────

class PostDetailPage extends StatefulWidget { //post page
  final Post post;
  const PostDetailPage({super.key, required this.post});

  @override
  State<PostDetailPage> createState() => _PostDetailPageState();
}

class _PostDetailPageState extends State<PostDetailPage> {
  final _ctrl = TextEditingController();

  void _addComment() {
    if (_ctrl.text.trim().isEmpty) return;
    setState(() {
      widget.post.comments.add(Comment(username: 'LucasDev', text: _ctrl.text.trim()));
    });
    _ctrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    final post = widget.post;
    return Scaffold(
      appBar: AppBar(title: const Text('Post')),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: _avatarColor(post.username),
                      child: Text(post.avatar, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(post.username, style: const TextStyle(fontWeight: FontWeight.bold)),
                        Text(post.timeAgo, style: TextStyle(color: Colors.grey[500], fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(post.content, style: const TextStyle(fontSize: 16)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Icon(post.liked ? Icons.favorite : Icons.favorite_border,
                        color: post.liked ? Colors.red : Colors.grey, size: 20),
                    const SizedBox(width: 4),
                    Text('${post.likes} likes'),
                  ],
                ),
                const Divider(height: 24),
                Text('Comments', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ...post.comments.map((c) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CircleAvatar(
                        radius: 14,
                        backgroundColor: _avatarColor(c.username),
                        child: Text(c.username[0].toUpperCase(),
                            style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(c.username, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                            Text(c.text),
                          ],
                        ),
                      ),
                    ],
                  ),
                )),
              ],
            ),
          ),
          const Divider(height: 1),
          Padding(
            padding: EdgeInsets.only(left: 16, right: 8, top: 8, bottom: MediaQuery.of(context).viewInsets.bottom + 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    decoration: const InputDecoration(
                      hintText: 'Add a comment...',
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      isDense: true,
                    ),
                  ),
                ),
                IconButton(icon: const Icon(Icons.send), onPressed: _addComment),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── SEARCH ───────────────────────────────────────────────────────────────────

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final _users = ['sparrowEx3', 'maria_photos', 'susoBryan', 'MagikW', 'STIPureGold', 'mayopoff'];
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final filtered = _users.where((u) => u.contains(_query.toLowerCase())).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Search')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              onChanged: (v) => setState(() => _query = v),
              decoration: const InputDecoration(
                hintText: 'Search users...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filtered.length,
              itemBuilder: (context, i) => ListTile(
                leading: CircleAvatar(
                  backgroundColor: _avatarColor(filtered[i]),
                  child: Text(filtered[i][0].toUpperCase(),
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
                title: Text(filtered[i]),
                subtitle: const Text('Tap to view profile'),
                onTap: () {},
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── CREATE POST ───────────────────────────────────────────────────────────────

class CreatePostPage extends StatefulWidget {
  final void Function(String) onPost;
  const CreatePostPage({super.key, required this.onPost});

  @override
  State<CreatePostPage> createState() => _CreatePostPageState();
}

class _CreatePostPageState extends State<CreatePostPage> {
  final _ctrl = TextEditingController();

  void _submit() {
    if (_ctrl.text.trim().isEmpty) return;
    widget.onPost(_ctrl.text.trim());
    _ctrl.clear();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Post shared! 🎉'), duration: Duration(seconds: 2)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('New Post'),
        actions: [
          TextButton(onPressed: _submit, child: const Text('Share', style: TextStyle(fontWeight: FontWeight.bold))),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  backgroundColor: _avatarColor('LucasDev'),
                  child: const Text('L', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    maxLines: 6,
                    maxLength: 280,
                    decoration: const InputDecoration(
                      hintText: "What's on your mind?",
                      border: InputBorder.none,
                    ),
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ],
            ),
            const Divider(),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.image_outlined, color: Colors.grey[500]),
                const SizedBox(width: 16),
                Icon(Icons.emoji_emotions_outlined, color: Colors.grey[500]),
                const SizedBox(width: 16),
                Icon(Icons.location_on_outlined, color: Colors.grey[500]),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ── PROFILE ───────────────────────────────────────────────────────────────────

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        actions: [IconButton(icon: const Icon(Icons.settings_outlined), onPressed: () {})],
      ),
      body: ListView(
        children: [
          const SizedBox(height: 24),
          Center(
            child: CircleAvatar(
              radius: 44,
              backgroundColor: _avatarColor('LucasDev'),
              child: const Text('L', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(height: 12),
          const Center(child: Text('LucasDev', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
          const Center(child: Text('@piattos · Joined today', style: TextStyle(color: Colors.grey))),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _stat('Posts', '1'),
              _stat('Followers', '0'),
              _stat('Following', '4'),
            ],
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: OutlinedButton(
              onPressed: () {},
              child: const Text('Edit Profile'),
            ),
          ),
          const Divider(height: 32),
          const Center(child: Text('Your posts will appear here', style: TextStyle(color: Colors.grey))),
        ],
      ),
    );
  }

  Widget _stat(String label, String value) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.grey)),
      ],
    );
  }
}